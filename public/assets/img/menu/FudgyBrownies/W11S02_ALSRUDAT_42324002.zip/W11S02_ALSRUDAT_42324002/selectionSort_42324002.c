/*
    Nama : Brahmana Purba
    NIM  : 42324002
    Nama Program : Selection Sort
*/

#include <stdio.h>
#include <stdlib.h>

void printArray(int Array[], int N);

void selectionSort (int Array[], int N) {
    int i, j, min_idx, k;
    for(i = 0; i < N-1; i++) {
        min_idx = i;
        for (j = i+1; j < N; j++){
          if (Array[j] < Array[min_idx])
            min_idx = j;
        }

        int temp = Array[min_idx];
        Array[min_idx] = Array[i];
        Array[i] = temp;

        printf("Pass-%d: ", i + 1);
        printArray(Array, N);
    }
}

void inputArray(int Array[], int N) {
    int i;
    for (i = 0; i < N; i++) {
        scanf("%d", &Array[i]);
    }
}

void printArray(int Array[], int N) {
    int i;

    for (i = 0; i < N; i ++) {
        printf("%d ", Array[i]);
    }
    printf("\n");
}

int main(){
    int Array[100];
    int i, N;

    printf("Enter Number of Array: ");
    scanf("%d", &N);
    printf("Enter %d Element Array: ", N);
    inputArray(Array, N);
    printf("Original Sequence: ");
    printArray(Array, N);
    printf("Sorted using Selection Sort:\n"); 
    selectionSort(Array, N);
}