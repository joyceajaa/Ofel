/*
    Nama : Brahmana Purba
    NIM  : 42324002
    Nama Program : Insertion Sort (Penulisan Variabel Dimodifikasi)
*/

#include <stdio.h>
#include <stdlib.h>

void insertion_sort(int array[], int n) {
    int i, j, key, k;
    for (i = 1; i < n; i++) {
        key = array[i];
        j = i - 1;

        while (j >= 0 && key < array[j]) {
            array[j + 1] = array[j];
            j = j - 1;
        }
        array[j + 1] = key;

        printf("Pass-%d: ", i);
        for (k = 0; k < n; k++) {
            printf("%d ", array[k]);
        }
        printf("\n");
    }
}

void input_array(int array[], int n) {
    int i;
    for (i = 0; i < n; i++) {
        scanf("%d", &array[i]);
    }
}

void print_array(int array[], int n) {
    int i;
    for (i = 0; i < n; i++) {
        printf("%d ", array[i]);
    }
    printf("\n");
}

int main() {
    int array[100];
    int i, n;

    printf("Masukkan jumlah elemen array: ");
    scanf("%d", &n);
    printf("Masukkan %d elemen: ", n);
    input_array(array, n);
    printf("Data sebelum diurutkan: ");
    print_array(array, n);
    printf("Proses pengurutan dengan Insertion Sort:\n");
    insertion_sort(array, n);

    return 0;
}
